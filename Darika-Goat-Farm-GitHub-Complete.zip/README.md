# Darika Goat Farm App

## Files
- `index.html` — main app (fixed dashboard goat update list and save handling)
- `manifest.webmanifest` — PWA metadata
- `sw.js` — service worker for offline caching

## GitHub upload
Upload the files in this ZIP to the root of your GitHub repository. If GitHub Pages is used, enable it in repository Settings → Pages and serve from the branch/folder containing `index.html`.

## Important
The app stores records in the browser's local storage on each device. Before replacing an older app, use **Backup / Settings → Export Full Backup** in the old app. Import the JSON backup in the new app on the same device/browser if you need to restore records.

The manifest and service worker are included for PWA hosting. The service worker requires HTTPS (such as GitHub Pages) or localhost.
